<?php 
include_once('../../model/model.php');
include_once('../../model/airfiles/airfiles_read.php');

$airfilesRead = new AirFiles;
?>