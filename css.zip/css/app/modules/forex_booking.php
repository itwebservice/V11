<?php 
header("Content-type: text/css");
?>
.forex_module .forex_chk{
	float:left;
	min-width:200px;
	margin-bottom:10px;
}
.forex_module h6{
	border-bottom: 1px solid #eaeaea; 
	padding-bottom: 5px;
	margin-top:0;
}