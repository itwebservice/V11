<?php 
header("Content-type: text/css");
?>
/*=================Booking css start==================*/
#tbl_hotel_booking input[type="text"], 
#tbl_hotel_booking_update input[type="text"],
#tbl_hotel_booking select, 
#tbl_hotel_booking_update select,
#tbl_hotel_booking textarea, 
#tbl_hotel_booking_update textarea{
	height: 40px;
	font-size: 12px;
}
#tbl_hotel_booking select[name="received_documents"], 
#tbl_hotel_booking_update select[name="received_documents"]{
	height: 50px;
}
#tbl_hotel_booking td, 
#tbl_hotel_booking_update td{
    padding: 8px 4px;
}
#tbl_hotel_booking td, 
#tbl_hotel_booking_update td{
    padding: 8px 4px;
}
/*=================Booking css end==================*/